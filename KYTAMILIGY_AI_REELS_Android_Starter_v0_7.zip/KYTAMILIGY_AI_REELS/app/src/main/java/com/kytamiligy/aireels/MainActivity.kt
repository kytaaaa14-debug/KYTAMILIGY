package com.kytamiligy.aireels

import android.net.Uri
import android.content.ContentValues
import android.os.Build
import android.provider.MediaStore
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import org.json.JSONArray
import java.io.File
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private val Ink = Color(0xFF101722)
private val Panel = Color(0xFF1B2635)
private val Gold = Color(0xFFD6AD70)
private val Mint = Color(0xFF55D6A5)
private data class WordCue(val word: String, val start: Double, val end: Double)

private val CaptionColors = listOf(Color(0xFFFFD84D), Color(0xFFFF5D67), Color(0xFF58D7FF), Color.White)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Ink, surface = Panel)) { EditorHome() } }
    }
}

@Composable
fun EditorHome() {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var caption by remember { mutableStateOf("التشطيب الصح بيبدأ من التأسيس") }
    var selectedColor by remember { mutableIntStateOf(0) }
    var projectName by remember { mutableStateOf("مشروعي الأول") }
    var aiStatus by remember { mutableStateOf("ارفع فيديو لبدء المونتاج") }
    var serverUrl by remember { mutableStateOf("http://10.0.2.2:8000") }
    var transcriptText by remember { mutableStateOf("") }
    var wordCues by remember { mutableStateOf(listOf<WordCue>()) }
    var playheadMs by remember { mutableLongStateOf(0L) }
    var isTranscribing by remember { mutableStateOf(false) }
    var isExporting by remember { mutableStateOf(false) }
    var captionSize by remember { mutableFloatStateOf(52f) }
    var captionPosition by remember { mutableStateOf("أسفل") }
    var cinematicLook by remember { mutableStateOf("natural") }
    var fadeEnabled by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) { videoUri = uri; aiStatus = "تم استيراد الفيديو — جاهز للتحرير" }
    }
    val player = remember(videoUri) {
        videoUri?.let {
            ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(it)); prepare() }
        }
    }
    DisposableEffect(player) { onDispose { player?.release() } }
    LaunchedEffect(player) {
        while (true) {
            if (player != null) playheadMs = player.currentPosition.coerceAtLeast(0L)
            delay(80)
        }
    }

    Column(Modifier.fillMaxSize().background(Ink).verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("KYTAMILIGY", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                Text("AI REELS STUDIO", color = Gold, fontSize = 11.sp, letterSpacing = 2.sp)
            }
            Surface(color = Color(0xFF263B37), shape = RoundedCornerShape(30.dp)) {
                Text("BETA 0.1", color = Mint, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("مشروع الفيديو", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            OutlinedTextField(projectName, { projectName = it }, modifier = Modifier.width(175.dp), singleLine = true, textStyle = LocalTextStyle.current.copy(fontSize = 12.sp))
        }
        Spacer(Modifier.height(12.dp))
        Surface(color = Color.Black, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().height(330.dp)) {
            if (player != null) {
                AndroidView(factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } }, modifier = Modifier.fillMaxSize())
            } else {
                Column(Modifier.fillMaxSize().clickable { picker.launch("video/*") }, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Icon(Icons.Default.Movie, null, tint = Gold, modifier = Modifier.size(52.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("استيراد فيديو", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("اضغط لاختيار فيديو من هاتفك", color = Color.LightGray, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(aiStatus, color = Mint, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            ActionTile("استيراد", Icons.Default.Add, Modifier.weight(1f)) { picker.launch("video/*") }
            ActionTile("قص ذكي", Icons.Default.ContentCut, Modifier.weight(1f)) {
                Toast.makeText(context, "سيتم تفعيل القص الذكي في مرحلة محرك AI", Toast.LENGTH_LONG).show()
            }
            ActionTile("ترجمة AI", Icons.Default.Subtitles, Modifier.weight(1f)) {
                val uri = videoUri
                if (uri == null) {
                    Toast.makeText(context, "استورد فيديو أولاً", Toast.LENGTH_SHORT).show()
                } else if (!isTranscribing) {
                    scope.launch {
                        isTranscribing = true
                        aiStatus = "جارٍ تحليل الكلام العربي..."
                        try {
                            val result = withContext(Dispatchers.IO) { uploadForTranscription(context, uri, serverUrl) }
                            transcriptText = result.optString("text")
                            val arr = result.optJSONArray("words")
                            wordCues = if (arr != null) (0 until arr.length()).mapNotNull { i ->
                                val item = arr.optJSONObject(i) ?: return@mapNotNull null
                                WordCue(item.optString("word"), item.optDouble("start"), item.optDouble("end"))
                            } else emptyList()
                            aiStatus = "اكتمل التفريغ: ${wordCues.size} كلمة"
                        } catch (e: Exception) {
                            aiStatus = "تعذر التفريغ: ${e.message ?: "تحقق من اتصال الخادم"}"
                        } finally { isTranscribing = false }
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = serverUrl, onValueChange = { serverUrl = it },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("عنوان خادم AI") },
            supportingText = { Text("للمحاكي: http://10.0.2.2:8000 — للهاتف استخدم عنوان خادم HTTPS") }
        )
        if (transcriptText.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text("النص المستخرج", color = Gold, fontWeight = FontWeight.Bold)
            Text(transcriptText, color = Color.White, fontSize = 13.sp)
        }
        Spacer(Modifier.height(18.dp))
        Text("النص المتحرك", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = caption, onValueChange = { caption = it }, modifier = Modifier.fillMaxWidth(), label = { Text("اكتب جملة الكابشن") })
        Spacer(Modifier.height(8.dp))
        Text("لون الكلمة", color = Color.LightGray, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CaptionColors.forEachIndexed { index, color ->
                Box(Modifier.size(34.dp).background(color, RoundedCornerShape(50)).then(if (selectedColor == index) Modifier.border(3.dp, Gold, RoundedCornerShape(50)) else Modifier).clickable { selectedColor = index })
            }
        }
        Spacer(Modifier.height(10.dp))
        Surface(color = Color(0xFF070B11), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
            Box(Modifier.padding(16.dp), contentAlignment = Alignment.Center) {
                Text(caption.ifBlank { "معاينة الكابشن" }, color = CaptionColors[selectedColor], fontWeight = FontWeight.Black, fontSize = 20.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("إعدادات الكابشن", color = Color.White, fontWeight = FontWeight.Bold)
        Text("حجم الخط: ${captionSize.toInt()}", color = Color.LightGray, fontSize = 12.sp)
        Slider(value = captionSize, onValueChange = { captionSize = it }, valueRange = 30f..84f)
        Text("مكان ظهور الكلمات", color = Color.LightGray, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("أعلى", "وسط", "أسفل").forEach { place ->
                FilterChip(selected = captionPosition == place, onClick = { captionPosition = place }, label = { Text(place) })
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("المظهر السينمائي", color = Color.White, fontWeight = FontWeight.Bold)
        Text("اختار معالجة لونية للفيديو قبل التصدير", color = Color.LightGray, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            listOf("natural" to "طبيعي", "cinematic" to "سينمائي", "warm" to "دافئ", "vivid" to "ألوان قوية", "mono" to "أبيض وأسود").forEach { (key, label) ->
                FilterChip(selected = cinematicLook == key, onClick = { cinematicLook = key }, label = { Text(label) })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = fadeEnabled, onCheckedChange = { fadeEnabled = it })
            Text("دخول وخروج تدريجي للصورة والصوت", color = Color.White, fontSize = 12.sp)
        }
        Spacer(Modifier.height(18.dp))
        Text("معاينة الكلمات المتزامنة", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Spacer(Modifier.height(8.dp))
        val activeWordIndex = wordCues.indexOfFirst { playheadMs / 1000.0 >= it.start && playheadMs / 1000.0 < it.end }
        Surface(color = Color(0xFF070B11), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (wordCues.isEmpty()) {
                    Text("بعد تفريغ الصوت ستظهر هنا الكلمات بالتوقيت الحقيقي أثناء التشغيل", color = Color.LightGray, fontSize = 12.sp)
                } else {
                    val windowStart = (activeWordIndex - 4).coerceAtLeast(0)
                    val windowEnd = (activeWordIndex + 5).coerceAtMost(wordCues.size)
                    Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                        (windowStart until windowEnd).forEach { index ->
                            val active = index == activeWordIndex
                            Text(
                                wordCues[index].word + " ",
                                color = if (active) CaptionColors[selectedColor] else Color.White.copy(alpha = .65f),
                                fontWeight = if (active) FontWeight.Black else FontWeight.Medium,
                                fontSize = if (active) 20.sp else 16.sp
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("الكلمة الحالية: ${wordCues.getOrNull(activeWordIndex)?.word ?: "—"}", color = Gold, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("مسارات المونتاج", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Spacer(Modifier.height(8.dp))
        Track("VIDEO", "المقطع الأصلي", Gold)
        Track("CAPTIONS", "النصوص المتحركة", Color(0xFFFFD84D))
        Track("AUDIO", "الصوت والموسيقى", Color(0xFF58D7FF))
        Track("BRAND", "شعار CYLISTA والخاتمة", Color(0xFFB69CFF))
        Spacer(Modifier.height(18.dp))
        Button(onClick = {
            val uri = videoUri
            if (uri == null) {
                Toast.makeText(context, "استورد فيديو أولاً", Toast.LENGTH_SHORT).show()
            } else if (wordCues.isEmpty()) {
                Toast.makeText(context, "نفّذ ترجمة AI أولاً للحصول على توقيت الكلمات", Toast.LENGTH_LONG).show()
            } else if (!isExporting) {
                scope.launch {
                    isExporting = true
                    aiStatus = "جارٍ تركيب الكلمات وتصدير MP4..."
                    try {
                        val outputUri = withContext(Dispatchers.IO) {
                            renderAndSaveVideo(context, uri, serverUrl, wordCues, captionSize.toInt(), captionPosition, cinematicLook, fadeEnabled)
                        }
                        aiStatus = "تم حفظ الفيديو في المعرض"
                        Toast.makeText(context, "تم حفظ الفيديو: $outputUri", Toast.LENGTH_LONG).show()
                    } catch (e: Exception) {
                        aiStatus = "فشل التصدير: ${e.message ?: "تحقق من الخادم"}"
                    } finally { isExporting = false }
                }
            }
        }, enabled = !isExporting, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) {
            Icon(Icons.Default.AutoAwesome, null)
            Spacer(Modifier.width(8.dp))
            Text(if (isExporting) "جارٍ التصدير..." else "تصدير MP4 إلى المعرض", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        Text("التصدير يحتاج خادم backend متاحًا، مع إعداد Google Cloud لخدمة التفريغ. يتم تركيب الكلمات الموقّتة على الفيديو ثم حفظ MP4 في المعرض.", color = Color.Gray, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

private suspend fun uploadForTranscription(
    context: android.content.Context,
    uri: Uri,
    baseUrl: String
): JSONObject {
    val input = context.contentResolver.openInputStream(uri) ?: error("لا يمكن قراءة الفيديو")
    val temp = File(context.cacheDir, "kytamiligy_upload_${System.currentTimeMillis()}.mp4")
    input.use { source -> temp.outputStream().use { target -> source.copyTo(target) } }
    try {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("file", "clip.mp4", temp.asRequestBody("video/mp4".toMediaType()))
            .build()
        val url = baseUrl.trimEnd('/') + "/transcribe"
        val request = Request.Builder().url(url).post(body).build()
        val response = OkHttpClient().newCall(request).execute()
        val responseText = response.body?.string().orEmpty()
        if (!response.isSuccessful) {
            val message = try { JSONObject(responseText).optString("detail") } catch (_: Exception) { responseText }
            error(message.ifBlank { "خطأ من خادم التفريغ (${response.code})" })
        }
        return JSONObject(responseText)
    } finally {
        temp.delete()
    }
}

private suspend fun renderAndSaveVideo(
    context: android.content.Context,
    uri: Uri,
    baseUrl: String,
    words: List<WordCue>,
    fontSize: Int,
    position: String,
    lookPreset: String,
    fadeEnabled: Boolean
): Uri {
    val temp = File(context.cacheDir, "kytamiligy_render_input_${System.currentTimeMillis()}.mp4")
    context.contentResolver.openInputStream(uri)?.use { input ->
        temp.outputStream().use { output -> input.copyTo(output) }
    } ?: error("لا يمكن قراءة ملف الفيديو")

    try {
        val wordsArray = JSONArray()
        words.forEach { cue ->
            wordsArray.put(JSONObject().put("word", cue.word).put("start", cue.start).put("end", cue.end))
        }
        val positionValue = when (position) {
            "أعلى" -> "top"
            "وسط" -> "center"
            else -> "bottom"
        }
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("file", "clip.mp4", temp.asRequestBody("video/mp4".toMediaType()))
            .addFormDataPart("words_json", wordsArray.toString())
            .addFormDataPart("font_size", fontSize.toString())
            .addFormDataPart("vertical_position", positionValue)
            .addFormDataPart("look_preset", lookPreset)
            .addFormDataPart("fade_enabled", fadeEnabled.toString())
            .build()
        val request = Request.Builder()
            .url(baseUrl.trimEnd('/') + "/render")
            .post(body)
            .build()
        val response = OkHttpClient().newCall(request).execute()
        val responseBytes = response.body?.bytes() ?: ByteArray(0)
        if (!response.isSuccessful) {
            val detail = try { JSONObject(String(responseBytes)).optString("detail") } catch (_: Exception) { "خطأ من خادم التصدير (${response.code})" }
            error(detail)
        }
        if (responseBytes.isEmpty()) error("الخادم أعاد ملفًا فارغًا")

        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "KYTAMILIGY_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/KYTAMILIGY")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        val outputUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("تعذر إنشاء ملف في معرض الهاتف")
        try {
            resolver.openOutputStream(outputUri)?.use { it.write(responseBytes) }
                ?: error("تعذر الكتابة في معرض الهاتف")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                resolver.update(outputUri, done, null, null)
            }
            return outputUri
        } catch (e: Exception) {
            resolver.delete(outputUri, null, null)
            throw e
        }
    } finally {
        temp.delete()
    }
}

@Composable
private fun ActionTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(12.dp), modifier = modifier.clickable(onClick = onClick)) {
        Column(Modifier.padding(vertical = 13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Gold)
            Spacer(Modifier.height(5.dp))
            Text(label, color = Color.White, fontSize = 11.sp)
        }
    }
}

@Composable
private fun Track(tag: String, title: String, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(tag, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(72.dp))
        Surface(color = color.copy(alpha = .18f), shape = RoundedCornerShape(6.dp), modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp))
        }
    }
}
