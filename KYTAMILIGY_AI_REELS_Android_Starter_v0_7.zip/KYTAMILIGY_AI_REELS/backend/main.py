import os, tempfile, subprocess
from pathlib import Path
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask
from fastapi import FastAPI, UploadFile, File, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from google.cloud import speech

app = FastAPI(title="KYTAMILIGY AI REELS Speech Service", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=False,
    allow_methods=["POST", "GET"], allow_headers=["*"]
)

MAX_UPLOAD_BYTES = 150 * 1024 * 1024
MAX_SECONDS = 60  # MVP synchronous Google Speech-to-Text limit for inline audio


@app.post("/render")
async def render_reel(
    file: UploadFile = File(...),
    words_json: str = Form(...),
    font_size: int = Form(52),
    vertical_position: str = Form("bottom"),
    look_preset: str = Form("natural"),
    fade_enabled: bool = Form(True),
):
    """Burn timed Arabic word captions into an MP4 and return the rendered file."""
    import json
    suffix = Path(file.filename or "clip.mp4").suffix or ".mp4"
    if suffix.lower() not in {".mp4", ".mov", ".m4v", ".webm", ".mkv"}:
        raise HTTPException(415, "ارفع فيديو مدعوم")
    try:
        words = json.loads(words_json)
        if not isinstance(words, list) or len(words) > 1500:
            raise ValueError("invalid words")
        normalized = []
        for item in words:
            word = str(item.get("word", "")).replace("{", "").replace("}", "").replace("\\", "")
            start, end = float(item["start"]), float(item["end"])
            if word and 0 <= start < end:
                normalized.append((word, start, end))
        if not normalized:
            raise ValueError("empty words")
    except Exception as exc:
        raise HTTPException(400, "بيانات توقيت الكلمات غير صحيحة") from exc

    data = await file.read()
    if not data or len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(413, "الفيديو فارغ أو أكبر من 150 ميجابايت")
    font_size = max(24, min(int(font_size), 96))
    alignment = 2 if vertical_position == "bottom" else (8 if vertical_position == "top" else 5)

    tmp = tempfile.TemporaryDirectory(prefix="kytamiligy_render_")
    folder = Path(tmp.name)
    source, ass, output = folder / f"input{suffix}", folder / "captions.ass", folder / "output.mp4"
    source.write_bytes(data)

    # ASS uses separate timed dialogue events so each spoken word appears on cue.
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Noto Sans Arabic,{font_size},&H0000D7FF,&H0000D7FF,&HAA000000,&H66000000,-1,0,0,0,100,100,0,0,1,4,2,{alignment},60,60,100,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    def ass_time(seconds):
        cs = int(round(seconds * 100))
        h, rem = divmod(cs, 360000)
        m, rem = divmod(rem, 6000)
        sec, centi = divmod(rem, 100)
        return f"{h}:{m:02d}:{sec:02d}.{centi:02d}"

    lines = [header]
    palette = ["&H0000D7FF", "&H0058D7FF", "&H0055D6A5", "&H00FFFFFF"]
    for i, (word, start, end) in enumerate(normalized):
        color = palette[i % len(palette)]
        safe_word = word.replace(",", "，").replace("\n", " ")
        # Bold, outlined, centered word; each event is timed to the recognizer cue.
        lines.append(
            f"Dialogue: 0,{ass_time(start)},{ass_time(end)},Default,,0,0,0,,"
            f"{{\\c{color}\\bord4\\shad2}}{safe_word}\n"
        )
    ass.write_text("".join(lines), encoding="utf-8-sig")
    # Restrict look names to a fixed allowlist; never accept arbitrary FFmpeg filter text.
    look_filters = {
        "natural": [],
        "cinematic": ["eq=contrast=1.12:saturation=0.88:brightness=-0.015", "unsharp=5:5:0.45:5:5:0.0"],
        "warm": ["eq=contrast=1.05:saturation=1.08:gamma_r=1.04:gamma_b=0.97"],
        "vivid": ["eq=contrast=1.08:saturation=1.28"],
        "mono": ["hue=s=0", "eq=contrast=1.08"],
    }
    selected_filters = look_filters.get(look_preset, [])
    try:
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", str(source)],
            capture_output=True, text=True, check=True, timeout=30
        )
        duration = max(0.1, float(probe.stdout.strip()))
        vf_parts = list(selected_filters)
        if fade_enabled:
            fade_out_start = max(0.0, duration - 0.6)
            vf_parts.extend(["fade=t=in:st=0:d=0.45", f"fade=t=out:st={fade_out_start:.3f}:d=0.6"])
        vf_parts.append(f"subtitles={ass}:charenc=UTF-8")
        audio_filters = []
        if fade_enabled:
            audio_filters = ["-af", "afade=t=in:st=0:d=0.35,afade=t=out:st=" + f"{max(0.0, duration - 0.6):.3f}" + ":d=0.6"]
        subprocess.run(
            ["ffmpeg", "-y", "-i", str(source), "-vf", ",".join(vf_parts),
             *audio_filters, "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
             "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(output)],
            capture_output=True, check=True, timeout=600
        )
    except subprocess.TimeoutExpired as exc:
        tmp.cleanup()
        raise HTTPException(504, "انتهت مهلة معالجة الفيديو") from exc
    except Exception as exc:
        tmp.cleanup()
        raise HTTPException(500, "فشل تركيب الكلمات على الفيديو. تحقق من دعم FFmpeg للترجمة العربية.") from exc

    return FileResponse(
        output, media_type="video/mp4", filename="KYTAMILIGY_reel.mp4",
        background=BackgroundTask(tmp.cleanup)
    )

@app.get("/health")
def health():
    return {"ok": True, "service": "kytamiligy-speech", "language": "ar-EG"}

@app.post("/transcribe")
async def transcribe(file: UploadFile = File(...)):
    suffix = Path(file.filename or "clip.mp4").suffix or ".mp4"
    if suffix.lower() not in {".mp4", ".mov", ".m4v", ".webm", ".mkv"}:
        raise HTTPException(415, "ارفع فيديو MP4 أو MOV أو WebM أو MKV")
    data = await file.read()
    if not data:
        raise HTTPException(400, "الملف فارغ")
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(413, "حجم الفيديو أكبر من 150 ميجابايت")

    with tempfile.TemporaryDirectory(prefix="kytamiligy_") as tmp:
        source = Path(tmp) / f"input{suffix}"
        audio = Path(tmp) / "audio.wav"
        source.write_bytes(data)
        try:
            probe = subprocess.run(
                ["ffprobe", "-v", "error", "-show_entries", "format=duration",
                 "-of", "default=noprint_wrappers=1:nokey=1", str(source)],
                capture_output=True, text=True, check=True, timeout=30
            )
            duration = float(probe.stdout.strip())
            if duration > MAX_SECONDS:
                raise HTTPException(
                    413,
                    "النسخة التجريبية تدعم فيديو حتى 60 ثانية. دعم المقاطع الأطول يحتاج تشغيلًا غير متزامن وتخزينًا سحابيًا."
                )
            subprocess.run(
                ["ffmpeg", "-y", "-i", str(source), "-vn", "-ac", "1",
                 "-ar", "16000", "-c:a", "pcm_s16le", str(audio)],
                capture_output=True, check=True, timeout=90
            )
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(422, "تعذر استخراج الصوت من الفيديو. تأكد من سلامة الملف.") from exc

        try:
            client = speech.SpeechClient()
            with audio.open("rb") as f:
                content = f.read()
            config = speech.RecognitionConfig(
                encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
                sample_rate_hertz=16000,
                language_code="ar-EG",
                enable_word_time_offsets=True,
                enable_automatic_punctuation=True,
                model="latest_long",
            )
            response = client.recognize(config=config, audio=speech.RecognitionAudio(content=content))
        except Exception as exc:
            raise HTTPException(
                502,
                "فشل الاتصال بخدمة Google Speech-to-Text. راجع إعدادات Google Cloud وبيانات الاعتماد."
            ) from exc

        words = []
        full_text = []
        for result in response.results:
            if not result.alternatives:
                continue
            alt = result.alternatives[0]
            full_text.append(alt.transcript)
            for w in alt.words:
                words.append({
                    "word": w.word,
                    "start": w.start_time.total_seconds(),
                    "end": w.end_time.total_seconds(),
                })
        return {"text": " ".join(full_text), "words": words, "language": "ar-EG", "duration": duration}
