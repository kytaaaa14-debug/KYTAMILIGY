# خادم تحويل الكلام إلى نص — KYTAMILIGY

## الوظيفة
يستقبل فيديو قصيرًا، يستخرج الصوت باستخدام FFmpeg، ثم يرسل الصوت إلى Google Cloud Speech-to-Text باللغة `ar-EG` مع توقيت بداية ونهاية كل كلمة.

## متطلبات الخادم
- Python 3.11+
- FFmpeg و ffprobe
- مشروع Google Cloud مع تفعيل Cloud Speech-to-Text API
- حساب خدمة Service Account بصلاحية استخدام Speech-to-Text
- تعيين `GOOGLE_APPLICATION_CREDENTIALS` على الخادم فقط

## تشغيل محلي
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export GOOGLE_APPLICATION_CREDENTIALS=/absolute/path/service-account.json
uvicorn main:app --host 0.0.0.0 --port 8000
```

## اختبار
```bash
curl -F "file=@sample.mp4" http://localhost:8000/transcribe
```

## حدود النسخة الأولى
- الحد الأقصى للفيديو 60 ثانية و150MB.
- يلزم HTTPS عند نشر الخدمة على الإنترنت.
- استخدم مصادقة للمستخدمين وحدود استخدام ومراقبة التكلفة قبل النشر العام.
- الملفات المؤقتة تحذف بعد انتهاء الطلب.
- هذه خدمة MVP؛ لم تُنشر على خادم عام ولم تُختبر بمفتاح/مشروع Google Cloud فعلي.


## حرق الكلمات داخل الفيديو
يوجد endpoint تجريبي `POST /render` يستقبل:
- `file`: ملف الفيديو.
- `words_json`: مصفوفة JSON مثل `[{"word":"أهلاً","start":0.2,"end":0.8}]`.
- `font_size`: حجم الخط بين 24 و96.
- `vertical_position`: `top` أو `center` أو `bottom`.

يرجع MP4 مع الكلمات المحروقة داخل الصورة. يعتمد ذلك على FFmpeg مع فلتر subtitles وخطوط Noto. هذه أول نسخة تجريبية من الحرق؛ اختبر جودة تشكيل العربية واتجاهها على عينات فعلية قبل الإنتاج.
